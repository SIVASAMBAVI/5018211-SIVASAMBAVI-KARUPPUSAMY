package com.example.EmployeeManagementSystem6.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.EmployeeManagementSystem6.entity.Employee;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
    
    // Custom query method using method name
    List<Employee> findByLastName(String lastName);
    
    // Custom query method using @Query annotation
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    List<Employee> findByEmail(@Param("email") String email);
    
    // Named queries defined in the Employee entity
    List<Employee> findByDepartmentName(@Param("departmentName") String departmentName);
}
