package com.ems.details.employee;

import jakarta.persistence.*;


import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.BatchSize;

@Entity
@BatchSize(size = 10)
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NaturalId
    private String email;

    private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

   
}