package com.example.EmployeeManagementSystem6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem6Application {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystem6Application.class, args);
    }
}
