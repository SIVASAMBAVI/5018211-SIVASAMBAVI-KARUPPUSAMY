package com.example.EmployeeManagementSystem6.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Department {
    @Id
    private Long id;
    private String name;

    // Getters and setters
}
