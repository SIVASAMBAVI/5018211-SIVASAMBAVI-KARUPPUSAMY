package com.example.EmployeeManagementSystem9;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagementSystem9Application {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagementSystem9Application.class, args);
    }
}
