package com.example.employeemanagementsystem8.projection;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class EmployeeFullNameProjection {
    private String fullName;

    public EmployeeFullNameProjection(String firstName, String lastName) {
        this.fullName = firstName + " " + lastName;
    }
}
