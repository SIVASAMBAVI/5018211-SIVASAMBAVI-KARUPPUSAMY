public class main {
    public static void main(String[] args) {
        Computer gamingComputer = new Computer.Builder()
            .setCPU("Intel i9")
            .setRAM("32GB")
            .setStorage("1TB SSD")
            .setHasGraphicsCard(true)
            .setHasBluetooth(true)
            .build();
        Computer officeComputer = new Computer.Builder()
            .setCPU("Intel i5")
            .setRAM("16GB")
            .setStorage("512GB SSD")
            .setHasGraphicsCard(false)
            .setHasBluetooth(true)
            .build();
        Computer basicComputer = new Computer.Builder()
            .setCPU("Intel i3")
            .setRAM("8GB")
            .setStorage("256GB SSD")
            .setHasGraphicsCard(false)
            .setHasBluetooth(false)
            .build();
        System.out.println(gamingComputer);
        System.out.println(officeComputer);
        System.out.println(basicComputer);
    }
}
