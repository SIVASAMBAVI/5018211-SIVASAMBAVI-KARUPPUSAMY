public class main {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket();
        Observer mobileApp = new MobileApp();
        Observer webApp = new WebApp();
        stockMarket.registerObserver(mobileApp);
        stockMarket.registerObserver(webApp);
        stockMarket.setPrice(100.0);
        stockMarket.setPrice(105.5);
        stockMarket.deregisterObserver(webApp);
        stockMarket.setPrice(110.0);
    }
}
