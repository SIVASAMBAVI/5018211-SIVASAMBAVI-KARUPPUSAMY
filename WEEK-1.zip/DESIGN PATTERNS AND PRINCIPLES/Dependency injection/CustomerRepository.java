interface CustomerRepository {
    String findCustomerById(int id);
}
class CustomerRepositoryImpl implements CustomerRepository {
    @Override
    public String findCustomerById(int id) {
        if (id == 1) {
            return "John Doe";
        } else if (id == 2) {
            return "Jane Smith";
        } else {
            return "Customer not found";
        }
    }
}
class CustomerService {
    private CustomerRepository customerRepository;
    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }
    public String getCustomerName(int id) {
        return customerRepository.findCustomerById(id);
    }
}
