public class main {
    public static void main(String[] args) {
        CustomerRepository customerRepository = new CustomerRepositoryImpl();
        CustomerService customerService = new CustomerService(customerRepository);
        System.out.println("Customer with ID 1: " + customerService.getCustomerName(1));
        System.out.println("Customer with ID 2: " + customerService.getCustomerName(2));
        System.out.println("Customer with ID 3: " + customerService.getCustomerName(3));
    }
}
