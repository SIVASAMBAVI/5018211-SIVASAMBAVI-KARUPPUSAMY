import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
            new Order(1, "Alice", 250.75),
            new Order(2, "Bob", 150.50),
            new Order(3, "Charlie", 300.40),
            new Order(4, "Dave", 100.20),
            new Order(5, "Eve", 200.30)
        };
        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        Sort.bubbleSort(bubbleSortedOrders);
        System.out.println("Bubble Sorted Orders:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }
        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        Sort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("Quick Sorted Orders:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
