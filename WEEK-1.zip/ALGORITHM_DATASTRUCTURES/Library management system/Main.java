import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Lib library = new Lib();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("1. Add Book");
            System.out.println("2. Search Book by Title (Linear Search)");
            System.out.println("3. Search Book by Title (Binary Search)");
            System.out.println("4. Search Book by Author (Linear Search)");
            System.out.println("5. Search Book by Author (Binary Search)");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    System.out.print("Enter book ID: ");
                    int bookId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter book title: ");
                    String title = scanner.nextLine();
                    System.out.print("Enter book author: ");
                    String author = scanner.nextLine();
                    library.addBook(bookId, title, author);
                    System.out.println("Book added successfully.");
                    break;
                case 2:
                    System.out.print("Enter book title to search (Linear Search): ");
                    title = scanner.nextLine();
                    Book book1 = library.linearSearchByTitle(title);
                    if (book1 != null) {
                        System.out.println("Book found: " + book1);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter book title to search (Binary Search): ");
                    title = scanner.nextLine();
                    Book book2 = library.binarySearchByTitle(title);
                    if (book2 != null) {
                        System.out.println("Book found: " + book2);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter book author to search (Linear Search): ");
                    author = scanner.nextLine();
                    Book book3 = library.linearSearchByAuthor(author);
                    if (book3 != null) {
                        System.out.println("Book found: " + book3);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 5:
                    System.out.print("Enter book author to search (Binary Search): ");
                    author = scanner.nextLine();
                    Book book4 = library.binarySearchByAuthor(author);
                    if (book4 != null) {
                        System.out.println("Book found: " + book4);
                    } else {
                        System.out.println("Book not found.");
                    }
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}
