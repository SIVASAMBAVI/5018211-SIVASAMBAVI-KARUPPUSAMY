import java.util.Map;
import java.util.TreeMap;
public class Lib {
    private TreeMap<String, Book> booksByTitle = new TreeMap<>();
    private TreeMap<String, Book> booksByAuthor = new TreeMap<>();
    public void addBook(int bookId, String title, String author) {
        Book newBook = new Book(bookId, title, author);
        booksByTitle.put(title.toLowerCase(), newBook);
        booksByAuthor.put(author.toLowerCase(), newBook);
    }
    public Book linearSearchByTitle(String title) {
        for (Map.Entry<String, Book> entry : booksByTitle.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(title)) {
                return entry.getValue();
            }
        }
        return null;
    }
    public Book binarySearchByTitle(String title) {
        return booksByTitle.get(title.toLowerCase());
    }
    public Book linearSearchByAuthor(String author) {
        for (Map.Entry<String, Book> entry : booksByAuthor.entrySet()) {
            if (entry.getKey().equalsIgnoreCase(author)) {
                return entry.getValue();
            }
        }
        return null;
    }
    public Book binarySearchByAuthor(String author) {
        return booksByAuthor.get(author.toLowerCase());
    }
}
class Book {
    private int bookId;
    private String title;
    private String author;
    public Book(int bookId, String title, String author) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
    }
    public int getBookId() {
        return bookId;
    }
    public String getTitle() {
        return title;
    }
    public String getAuthor() {
        return author;
    }
    @Override
    public String toString() {
        return "Book = " +"bookId=" + bookId + ", title='" + title + '\'' + ", author='" + author ;
    }
}
