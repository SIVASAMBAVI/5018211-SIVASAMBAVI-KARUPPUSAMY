import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Forecast forecastTool = new Forecast();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("1. Add Growth Rate");
            System.out.println("2. Predict Future Value");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    System.out.print("Enter year: ");
                    int year = scanner.nextInt();
                    System.out.print("Enter growth rate (%) for year " + year + ": ");
                    double rate = scanner.nextDouble();
                    forecastTool.addGrowthRate(year, rate);
                    System.out.println("Growth rate added successfully.");
                    break;
                case 2:
                    System.out.print("Enter initial value: ");
                    double initialValue = scanner.nextDouble();
                    System.out.print("Enter number of years for prediction: ");
                    int years = scanner.nextInt();
                    double futureValue = forecastTool.predictFutureValue(initialValue, years);
                    System.out.printf("Predicted future value after %d years: %.2f\n", years, futureValue);
                    break;
                case 3:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}
