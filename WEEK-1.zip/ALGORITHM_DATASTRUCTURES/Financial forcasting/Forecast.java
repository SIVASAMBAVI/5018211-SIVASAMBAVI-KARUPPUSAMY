import java.util.Map;
import java.util.TreeMap;
public class Forecast {
    private TreeMap<Integer, Double> growthRates = new TreeMap<>();

    public void addGrowthRate(int year, double rate) {
        growthRates.put(year, rate);
    }
    public double predictFutureValue(double initialValue, int years) {
        return predictFutureValueRecursive(initialValue, years, 0);
    }
    private double predictFutureValueRecursive(double currentValue, int remainingYears, int currentYear) {
        if (remainingYears == 0) {
            return currentValue;
        }
        double growthRate = growthRates.getOrDefault(currentYear, 0.0);
        double nextValue = currentValue * (1 + growthRate / 100);
        return predictFutureValueRecursive(nextValue, remainingYears - 1, currentYear + 1);
    }
}
