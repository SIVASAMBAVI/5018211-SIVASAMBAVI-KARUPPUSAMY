import java.util.Arrays;
import java.util.HashMap;
public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Smartphone", "Electronics"),
            new Product(3, "Shirt", "Apparel"),
            new Product(4, "Shoes", "Apparel"),
            new Product(5, "Book", "Books")
        };
        Product linearResult = linearSearch(products, "Smartphone");
        if (linearResult != null) {
            System.out.println("Linear Search: " + linearResult);
        } else {
            System.out.println("Product not found using linear search.");
        }
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));
        Product binaryResult = binarySearch(products, "Smartphone");
        if (binaryResult != null) {
            System.out.println("Binary Search: " + binaryResult);
        } else {
            System.out.println("Product not found using binary search.");
        }
        HashMap<String, Product> productMap = new HashMap<>();
        for (Product product : products) {
            productMap.put(product.getProductName(), product);
        }
        Product hashMapResult = productMap.get("Smartphone");
        if (hashMapResult != null) {
            System.out.println("HashMap Search: " + hashMapResult);
        } else {
            System.out.println("Product not found using HashMap.");
        }
    }
    public static Product linearSearch(Product[] products, String productName) {
        for (Product product : products) {
            if (product.getProductName().equals(productName)) {
                return product;
            }
        }
        return null;
    }
    public static Product binarySearch(Product[] products, String productName) {
        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareTo(productName);

            if (comparison == 0) {
                return products[mid];
            }
            if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }
}
