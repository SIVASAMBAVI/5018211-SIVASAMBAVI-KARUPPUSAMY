import java.util.Scanner;
public class Main {
    private static Task head = null;
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;
        while (running) {
            System.out.println("1. Add Task");
            System.out.println("2. Search Task");
            System.out.println("3. Traverse Tasks");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    addTask(scanner);
                    break;
                case 2:
                    searchTask(scanner);
                    break;
                case 3:
                    traverseTasks();
                    break;
                case 4:
                    deleteTask(scanner);
                    break;
                case 5:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        scanner.close();
    }
    private static void addTask(Scanner scanner) {
        System.out.print("Enter task ID: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter task name: ");
        String taskName = scanner.nextLine();
        System.out.print("Enter task status: ");
        String status = scanner.nextLine();
        Task newTask = new Task(taskId, taskName, status);
        newTask.setNext(head);
        head = newTask;
        System.out.println("Task added successfully.");
    }
    private static void searchTask(Scanner scanner) {
        System.out.print("Enter task ID to search: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();  
        Task current = head;
        while (current != null) {
            if (current.getTaskId() == taskId) {
                System.out.println(current);
                return;
            }
            current = current.getNext();
        }
        System.out.println("Task not found.");
    }
    private static void traverseTasks() {
        if (head == null) {
            System.out.println("No tasks found.");
            return;
        }
        Task current = head;
        while (current != null) {
            System.out.println(current);
            current = current.getNext();
        }
    }
    private static void deleteTask(Scanner scanner) {
        System.out.print("Enter task ID to delete: ");
        int taskId = scanner.nextInt();
        scanner.nextLine();
        if (head == null) {
            System.out.println("No tasks to delete.");
            return;
        }
        if (head.getTaskId() == taskId) {
            head = head.getNext();
            System.out.println("Task deleted successfully.");
            return;
        }
        Task current = head;
        Task previous = null;
        while (current != null && current.getTaskId() != taskId) {
            previous = current;
            current = current.getNext();
        }
        if (current == null) {
            System.out.println("Task not found.");
        } else {
            previous.setNext(current.getNext());
            System.out.println("Task deleted successfully.");
        }
    }
}
