import java.util.HashMap;
import java.util.Map;
public class Main {
    private static Map<String, Product> inventory = new HashMap<>();

    public static void main(String[] args) {
        addProduct(new Product("P001", "Product 1", 100, 10.99));
        addProduct(new Product("P002", "Product 2", 150, 15.99));
        updateProduct("P001", "Updated Product 1", 120, 11.99);
        deleteProduct("P002");
        displayInventory();
    }
    public static void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
        System.out.println("Added: " + product);
    }
    public static void updateProduct(String productId, String newName, int newQuantity, double newPrice) {
        Product product = inventory.get(productId);
        if (product != null) {
            product.setProductName(newName);
            product.setQuantity(newQuantity);
            product.setPrice(newPrice);
            System.out.println("Updated: " + product);
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }
    public static void deleteProduct(String productId) {
        Product removedProduct = inventory.remove(productId);
        if (removedProduct != null) {
            System.out.println("Deleted: " + removedProduct);
        } else {
            System.out.println("Product with ID " + productId + " not found.");
        }
    }
    public static void displayInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Inventory is empty.");
        } else {
            System.out.println("Current Inventory:");
            for (Product product : inventory.values()) {
                System.out.println(product);
            }
        }
    }
}
